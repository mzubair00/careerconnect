<?php
include "config.php";
include "templates\\header.html";

if(!isset($_SESSION['username']))
{
    include "templates\\navigation-default.html";
} else {
    include "templates\\navigation-loggedin.html";
}

if(isset($_SESSION['username']))
{
    $currentuser = getUserbyID($conn,$_SESSION['user_id']);
    if($currentuser['permission'] == 0)
    {
        
        print "<main>";
        print "<h3>Users</h3>";
        $query = "select * from users";
        $result = $conn->query($query);
        if($result->num_rows > 0)
        {
            while($row = $result->fetch_assoc()){
                print $row['username'].", email: ".$row['email'].", permission: ".$row['permission']." <a href='permission.php?user_id=".$row['user_id']."'>Change Permission</a> </br>";
            }
        }
    }
    else{print "No access allowed.";}
}
else
{
    print "No access allowed.";
}



include "templates\\footer.html";