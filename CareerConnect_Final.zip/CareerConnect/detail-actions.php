<?php
include "config.php";
checkLoggedIn();



if(!array_key_exists("action", $_REQUEST) || !in_array($_REQUEST['action'], array('edit', 'update', 'delete'))) {
    print "<h4>No valid 'action' specified.</h4>";
}

if($_REQUEST['action'] == 'delete')
{
    $replyquery = "delete from attendees WHERE event_id = " .$_REQUEST['event_id'];
    mysqli_query($conn, $replyquery);
    $query = "delete from events WHERE event_id = " . $_REQUEST['event_id'];
        if(mysqli_query($conn, $query)) {
            header('Location: events.php');
        }
        else {
            di("<div class='alert alert-danger' role='alert'>ERROR during detail delete. ". mysqli_error($conn)."</div>");
        }
}

include "templates\\header.html";
include "templates\\navigation-loggedin.html";



if($_REQUEST['action'] == 'edit')
{
    $event = getEventById($conn, $_REQUEST['event_id']);

    $heading = "<h3>Update Event - ".$event['event_id']."</h3><br />\r\n";
    $button = "Update Event";
    $nextaction = "update";
    $event_id = $event['event_id'];
    $title = $event['title'];
    $description = $event['description'];
    $time_begin = $event['time_begin'];
    $time_end = $event['time_end'];
    $location = $event['location'];

}



if(isset($_POST['but_submit'])){

    $action = mysqli_real_escape_string($conn,$_POST['action']);
    $title = mysqli_real_escape_string($conn,$_POST['txt_title']);
    $description = mysqli_real_escape_string($conn,$_POST['txt_description']);
    $time_begin = mysqli_real_escape_string($conn,$_POST['txt_starttime']);
    $time_end = mysqli_real_escape_string($conn,$_POST['txt_endtime']);
    $location = mysqli_real_escape_string($conn,$_POST['txt_location']);

    
    if(isset($_POST['event_id'])) { $event_id = mysqli_real_escape_string($conn,$_POST['event_id']); }

    if($_REQUEST['action'] == 'update'){
        $query = "update events set title = '".$title."', description = '".$description."', location = '".$location."', time_begin = '".$time_begin."', time_end = '".$time_end."'  WHERE event_id = " . $event_id;
        if(mysqli_query($conn, $query)) {
           print '<div class="alert alert-success" role="alert">Event Successfully Updated. <a href=event-details.php?event_id='.$event_id.'>Back</a></div>';
        }
        else {
            $message = "<div class='alert alert-danger' role='alert'>ERROR during error update. ". mysqli_error($conn)."</div>";
            include "templates\\event-form.html";
        }
    }

} else {
    
    include "templates\\event-form.html";

}


include "templates\\footer.html";