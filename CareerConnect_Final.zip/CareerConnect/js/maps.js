var center = new google.maps.LatLng(0,0);      
var address = document.getElementById('location').innerHTML;
var geocoder;

function initialize() {
    // MAP ATTRIBUTES.
    geocoder = new google.maps.Geocoder();
    var mapAttr = {zoom: 15, cetner: center}
    geocoder.geocode({'address': address}, function(results,status)
    {
        if(status=='OK')
        {
            map.setCenter(results[0].geometry.location);
            var marker = new google.maps.Marker({
                map:map,
                position: results[0].geometry.location
            });
        } else{
            alert('Geocode failure: ' + status);
        }
    });

    const locationButton = document.createElement("button");

        // THE MAP TO DISPLAY.
    var map = new google.maps.Map(document.getElementById("mapContainer"), mapAttr);
}


google.maps.event.addDomListener(window, 'load', initialize);