<?php
include "config.php";
checkLoggedIn();



if(!array_key_exists("action", $_REQUEST) || !in_array($_REQUEST['action'], array('edit', 'update','insert', 'create', 'delete'))) {
    print "<h4>No valid 'action' specified.</h4>";
}

if($_REQUEST['action'] == 'delete')
{
    $post = getPostById($conn, $_REQUEST['post_id']);
    $replyquery = "delete from replies WHERE post_id = " .$_REQUEST['post_id'];
    mysqli_query($conn, $replyquery);
    $query = "delete from posts WHERE post_id = " . $_REQUEST['post_id'];
        if(mysqli_query($conn, $query)) {
            header('Location: posts.php?topic_id='.$post['topic_id']);
        }
        else {
            di("<div class='alert alert-danger' role='alert'>ERROR during post update. ". mysqli_error($conn)."</div>");
        }
}

include "templates\\header.html";
include "templates\\navigation-loggedin.html";

if($_REQUEST['action'] == 'create')
{
    $topic_id = $_REQUEST['topic_id'];
    $heading = "<h3>Create New Post</h3><br />\r\n";
    $button = "Create Post";
    $nextaction = "insert";
}

if($_REQUEST['action'] == 'edit')
{
    $post = getPostById($conn, $_REQUEST['post_id']);

    $heading = "<h3>Update Topic - ".$post['post_id']."</h3><br />\r\n";
    $button = "Update Post";
    $nextaction = "update";
    $topic_id = $post['topic_id'];
    $post_id = $post['post_id'];
    $title = $post['title'];
    $body = $post['body'];
}



if(isset($_POST['but_submit'])){

    $action = mysqli_real_escape_string($conn,$_POST['action']);
    $title = mysqli_real_escape_string($conn,$_POST['txt_title']);
    $body = mysqli_real_escape_string($conn,$_POST['txt_body']);
    $topic_id = mysqli_real_escape_string($conn,$_POST['topic_id']);
    
    if(isset($_POST['post_id'])) { $post_id = mysqli_real_escape_string($conn,$_POST['post_id']); }


    if($_REQUEST['action'] == 'insert'){
        $query = "INSERT INTO `posts` (`topic_id`,`user_id`,`title`,`body`,`create_time`,`edit_time`) VALUES (".$topic_id.",".$_SESSION['user_id'].",'".$title."','".$body."',NOW(),NOW())";
        if(mysqli_query($conn, $query)) {
           print '<div class="alert alert-success" role="alert">Post Successfully created. <a href=posts.php?topic_id='.$topic_id.'>Back</a></div> </div>';
        }
        else {
            $message = "<div class='alert alert-danger' role='alert'>ERROR during post creation. ". mysqli_error($conn)."</div>";
            include "templates\\post-form.html";
        }
    }

    elseif($_REQUEST['action'] == 'update'){
        $query = "update posts set title = '".$title."', body = '".$body."', edit_time = NOW() WHERE post_id = " . $post_id;
        if(mysqli_query($conn, $query)) {
           print '<div class="alert alert-success" role="alert">Post Successfully Updated. <a href=post.php?post_id='.$post_id.'>Back</a></div>';
        }
        else {
            $message = "<div class='alert alert-danger' role='alert'>ERROR during post update. ". mysqli_error($conn)."</div>";
            include "templates\\post-form.html";
        }
    }

} else {
    
    include "templates\\post-form.html";

}


include "templates\\footer.html";