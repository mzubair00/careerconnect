<?php
include "config.php";
include "templates\\header.html";

if(!isset($_SESSION['username']))
{
    include "templates\\navigation-default.html";
} else {
    include "templates\\navigation-loggedin.html";
}
$event_id = $_REQUEST['event_id'];
$username = $_SESSION['username'];

print "<main>";
//print "<h4>Beginning Time: ".$create_time."</h4>";

$event_query = "select * from events where event_id = ".$event_id;
        $eventinfo = $conn->query($event_query);
    
    if($eventinfo->num_rows > 0)
    {
        while($row = $eventinfo->fetch_assoc()){
            print "<h3>".$row['title']."</h3>";
            $hostuser = getUserById($conn, $row['user_id']);
            $hostname = $hostuser['firstname']." ".$hostuser['lastname'];
            $hostusername = $hostuser['username'];
            print "Host: " .$hostname."</br>Email: ".$hostuser['email']."</br>Description: ".$row['description']."</br>";
            print "Beginning Time: ".$row['time_begin']."</br>End Time: ".$row['time_end'];
            print "<div id='location'>".$row['location']."</div>";
            include "templates\\event-map.html";
            include "templates\\event-details.html";
            
        }
    }


$query = "select * from attendees where event_id = ".$event_id;
        $result = $conn->query($query);
        $attendeesize = $result->num_rows;

    print "<h4>Attendees: ".$attendeesize."</h4>";
    if((isset($_SESSION['username'])&&($_SESSION['username']) == $hostusername) || ($_SESSION['permission'] == 0))
    {
        {
            if($result->num_rows > 0)
            {
                while($row = $result->fetch_assoc()){
                    $user = getUserById($conn, $row['user_id']);
                    print   $user['username']." - ". $user['firstname'] . " " . $user['lastname'].", Comments: ".$row['comments']." <br/>";
                }
                
            }
        }
    }
    else {
    }
$rsvpquery = "select user_id from attendees where event_id = ".$event_id." and user_id = ".$_SESSION['user_id'];
    $result = $conn->query($rsvpquery);
    if(isset($_SESSION['username'])&&(($_SESSION['username']) != $hostusername)){
        if($result-> num_rows < 1)
        {
            if($_SESSION['permission'] <= 3) {
                print '<div class="row"><div class="col-12 text-center mb-3">';
                print '<a href="rsvp.php?action=create&event_id='.$event_id.'" class="btn btn-warning pull-right">RSVP</a>';
                print '</div></div>';
            }
        }
        else
        {
            if($_SESSION['permission'] <= 3) {
                print '<div class="row"><div class="col-12 text-center mb-3">';
                print '<a href="rsvp.php?action=delete&event_id='.$event_id.'" class="btn btn-warning pull-right">Cancel RSVP</a>';
                print '</div></div>';
            }
        }
    }
include "templates\\footer.html";
