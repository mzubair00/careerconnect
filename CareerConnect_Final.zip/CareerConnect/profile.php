<?php
include "config.php";
include "templates\\header.html";

if(!isset($_SESSION['username']))
{
    include "templates\\navigation-default.html";
} else {
    include "templates\\navigation-loggedin.html";
}

$currentuser = getUserbyID($conn,$_SESSION['user_id']);

print "<main>";
print "<h3>Profile</h3>";
print "<h4>Information:</h4>";
print "<p> Username: ".$currentuser['username']."</br>";
print "Full Name: ".$currentuser['firstname']." ".$currentuser['lastname']."</br>";
print "Email: ".$currentuser['email']."</br>";
print "Password: <a href=changepassword.php>Change Password</a></br>";
print "Location: ".$currentuser['location']."</br>";
print "Joined: ".$currentuser['create_time']."</br>";

include "templates\\footer.html";