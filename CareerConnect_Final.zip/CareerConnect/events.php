<?php
include "config.php";

checkLoggedIn();

include "templates\\header.html";
include "templates\\navigation-loggedin.html";




if($_SESSION['permission'] < 3) {
    print '<div class="row"><div class="col-12 text-center mb-3">';
    print '<a href="event.php?action=create" class="btn btn-warning pull-right">New Event</a>';
    print '</div></div>';
}

if(!isset($_REQUEST['type'])) { $type = "current"; } else { $type = $_REQUEST['type'];}

if($type == "current")
{
    print "<h3>Current Events</h3>";
    print "<a href=events.php?type=past>show past events</a><br /><br />";
}
elseif($type == "past")
{
    print "<h3>Past Events</h3>";
    print "<a href=events.php?type=current>show current events</a><br /><br />";
}

$events = getEvents($conn, $type);


if(sizeof($events)< 1)
{
    print "<p class='fs-4'>No Event Found.</p>";
}
else{
    foreach($events as &$event)
    {
        include "templates\\event-list.html";
    }
}

include "templates\\footer.html";