<?php
include "config.php";

checkLoggedIn();

include "templates\\header.html";
include "templates\\navigation-loggedin.html";

$topic_id = $_REQUEST['topic_id'];
$topic = getTopicById($conn,$topic_id);

print "<h3>".$topic['subj']."</h3><br />";
print "<div class='container'>";
if($_SESSION['permission'] != 4) {
    print '<div class="row"><div class="col-12 text-center mb-3">';
    print '<a href="post-actions.php?action=create&topic_id='.$topic_id.'" class="btn btn-warning pull-right">New Post</a>';
    print '</div></div>';
}

$posts = getPosts($conn, $topic_id);

if(sizeof($posts)< 1)
{
    print "<p class='fs-4'>No Posts Found.</p>";
}
else{
    foreach($posts as &$post)
    {
        include "templates\\post-list.html";
    }
}

include "templates\\footer.html";
