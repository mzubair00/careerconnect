<?php
include "config.php";
include "templates\\header.html";

if(!isset($_SESSION['username']))
{
    include "templates\\navigation-default.html";
} else {
    include "templates\\navigation-loggedin.html";
}

if(isset($_POST['but_submit'])){

    $currentpassword = mysqli_real_escape_string($conn,$_POST['txt_currentpassword']);
    $password = mysqli_real_escape_string($conn,$_POST['txt_password']);
    $password2 = mysqli_real_escape_string($conn,$_POST['txt_password2']);
    
    $user = getUserById($conn,$_SESSION['user_id']);
    $currentpass = $user['password'];

    if(password_verify($currentpassword, $currentpass))
    {
        if($password == $password2)
        {
            $pwhash = password_hash($password, PASSWORD_DEFAULT);
            $query = "update users set password = '".$pwhash."' where user_id = '".$user['user_id']."'";
            if(mysqli_query($conn, $query)) {
            print '<div class="alert alert-success" role="alert">Password Successfully Updated. <a href=profile.php> Back to Profile</a></div>';
            }
            else {
                $message = "<div class='alert alert-danger' role='alert'>ERROR during password update. ". mysqli_error($conn)."</div>";
            }
        }
        else
        {
            $message = "<div class='alert alert-danger' role='alert'>ERROR new password mismatch.". mysqli_error($conn)."</div>";
            
        }
    }
    elseif($currentpassword != $currentpass)
    {
        $message = "<div class='alert alert-danger' role='alert'>ERROR current password is incorrect. ". mysqli_error($conn)."</div>";
    }
    // if (
        
    //     $pwhash = password_hash($password, PASSWORD_DEFAULT);
    //     $query = "INSERT INTO `careerconnect`.`users` (`username`,`email`,`firstname`,`lastname`,`password`,`location`,`permission`) VALUES ('".$username."','".$email."','".$firstname."','".$lastname."','".$pwhash."','".$location."',3)";

    //     if(mysqli_query($conn, $query)) {
    //         $message = '<div class="alert alert-success" role="alert">Signup Successful. Please login at <a href="login.php">Login</a></div>';
    //     }
    //     else {
    //         $message = "<div class='alert alert-danger' role='alert'>ERROR during signup. ". mysqli_error($conn)."</div>";
    //     }
    // }
    // else {
    //     $message = "<div class='alert alert-danger' role='alert'>All fields are required.</div>";
    // }
}



include "templates\\change-password-form.html";
include "templates\\footer.html";