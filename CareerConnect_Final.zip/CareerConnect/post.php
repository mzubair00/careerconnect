<?php
include "config.php";
checkLoggedIn();

include "templates\\header.html";
include "templates\\navigation-loggedin.html";

if(!isset($_REQUEST['post_id'])){ print "<h4> No post id provided.";  }

else {
    $post_id = mysqli_real_escape_string($conn, $_REQUEST['post_id']);
    $post = getPostById($conn, $post_id);
    $replies = getReplies($conn, $post_id);
    if($_SESSION['permission'] != 4) {
        print '<div class="row"><div class="col-12 text-center mb-3">';
        print '<a href="reply-actions.php?action=create&post_id='.$post_id.'" class="btn btn-warning pull-right">New Reply</a>';
        print '</div></div>';
    }

    include "templates\\post-details.html";

    foreach($replies as &$reply)
    {  
        include "templates\\reply-details.html";
    }

}


include "templates\\footer.html";