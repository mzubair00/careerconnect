<?php
include "config.php";
include "templates\\header.html";

if(!isset($_SESSION['username']))
{
    include "templates\\navigation-default.html";
} else {
    include "templates\\navigation-loggedin.html";
}

if(isset($_SESSION['username']))
{
    $currentuser = getUserbyID($conn,$_SESSION['user_id']);
    if($currentuser['permission'] == 0)
    {
        if(isset($_POST['but_submit'])){

            $permission = mysqli_real_escape_string($conn,$_POST['txt_permission']);
            $user = getUserById($conn,$_REQUEST['user_id']);
            $query = "update users set permission = '".$permission."' where user_id = '".$user['user_id']."'";
            if(mysqli_query($conn, $query)) {
                print '<div class="alert alert-success" role="alert">Permission Successfully Updated. <a href=users.php> Back to Users</a></div>';
            }
            else {
                $message = "<div class='alert alert-danger' role='alert'>ERROR during permission update. ". mysqli_error($conn)."</div>";
                include "templates\\change-permission.html";
                }
        }
        include "templates\\change-permission.html";
    }
    else{
        print "No access allowed.";
    }
}
else{
    print "No access allowed.";
}



include "templates\\footer.html";