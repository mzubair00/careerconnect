<?php

include "config.php";

if(isset($_POST['but_submit'])){

    $username = mysqli_real_escape_string($conn,$_POST['txt_username']);
    $password = mysqli_real_escape_string($conn,$_POST['txt_password']);
    $password2 = mysqli_real_escape_string($conn,$_POST['txt_password2']);
    $firstname = mysqli_real_escape_string($conn,$_POST['txt_firstname']);
    $lastname = mysqli_real_escape_string($conn,$_POST['txt_lastname']);
    $email = mysqli_real_escape_string($conn,$_POST['txt_email']);
    $location = mysqli_real_escape_string($conn,$_POST['txt_location']);
    
    if ($username != "" && $password != "" && $password2 != "" && $firstname != "" && $lastname != "" && $email != "" && $location != "") {

        if($password == $password2)
        {
            $pwhash = password_hash($password, PASSWORD_DEFAULT);
            $query = "INSERT INTO `careerconnect`.`users` (`username`,`email`,`firstname`,`lastname`,`password`,`location`,`permission`) VALUES ('".$username."','".$email."','".$firstname."','".$lastname."','".$pwhash."','".$location."',3)";

            if(mysqli_query($conn, $query)) {
                $message = '<div class="alert alert-success" role="alert">Signup Successful. Please login at <a href="login.php">Login</a></div>';
            }
            else {
                $message = "<div class='alert alert-danger' role='alert'>ERROR during signup. ". mysqli_error($conn)."</div>";
            }
        }
        else{
            $message = "<div class='alert alert-danger' role='alert'>Password mismatch.</div>";
        }
    }
    else {
        $message = "<div class='alert alert-danger' role='alert'>All fields are required.</div>";
    }
}


include "templates\\header.html";
include "templates\\navigation-default.html";
include "templates\\signup.html";
include "templates\\footer.html";

//     $form = "<div class=container>";    
//     $form = $form . "<form method='post' action=''>";
//     $form = $form . "    <div id='div_login'>";
//     $form = $form . "        <h1>Sign Up</h1>";
//     $form = $form . "        <div>";
//     $form = $form . "            <input type='text' class='textbox' id='txt_username' name='txt_username' placeholder='Username' />";
//     $form = $form . "        </div>";
//     $form = $form . "        <div>";
//     $form = $form . "            <input type='password' class='textbox' id='txt_password' name='txt_password' placeholder='Password'/>";
//     $form = $form . "        </div>";
//     $form = $form . "        <div>";
//     $form = $form . "            <input type='password' class='textbox' id='txt_password2' name='txt_password2' placeholder='Confirm Password'/>";
//     $form = $form . "        </div>";
//     $form = $form . "        <div>";
//     $form = $form . "            <input type='text' class='textbox' id='txt_firstname' name='txt_firstname' placeholder='First Name'/>";
//     $form = $form . "        </div>";
//     $form = $form . "        <div>";
//     $form = $form . "            <input type='text' class='textbox' id='txt_lastname' name='txt_lastname' placeholder='Last Name'/>";
//     $form = $form . "        </div>";
//     $form = $form . "        <div>";
//     $form = $form . "            <input type='text' class='textbox' id='txt_email' name='txt_email' placeholder='Email Address'/>";
//     $form = $form . "        </div>";
//     $form = $form . "        <div>";
//     $form = $form . "            <input type='text' class='textbox' id='txt_location' name='txt_location' placeholder='Location'/>";
//     $form = $form . "        </div>";
//     $form = $form . "        <div>";
//     $form = $form . "            <input type='submit' value='Submit' name='but_submit' id='but_submit' />";
//     $form = $form . "        </div>";
//     if(isset($error))
//     {
//         $form = $form. "<div style='color: red; font-weight: bold><p>".$error."</p></div>";
//     }
//     $form = $form . "    </div>";
//     $form = $form . "</form>";
//     $form = $form . "</div>";
    

// print $form;