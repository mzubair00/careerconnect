<?php
include "config.php";
include "templates\\header.html";
include "templates\\navigation-loggedin.html";
checkLoggedIn();

$event_id = $_REQUEST['event_id'];
if(!array_key_exists("action", $_REQUEST) || !in_array($_REQUEST['action'], array('edit', 'update','insert', 'create', 'delete'))) {
    print "<h4>No valid 'action' specified.</h4>";
}


if($_REQUEST['action'] == 'delete')
{
    $query = "delete from attendees WHERE event_id = " . $event_id." and user_id = ".$_SESSION['user_id'];
        if(mysqli_query($conn, $query)) {
            header('Location: event-details.php?event_id='.$event_id);
        }
        else {
            di("<div class='alert alert-danger' role='alert'>ERROR during reply update. ". mysqli_error($conn)."</div>");
        }
}

if(isset($_POST['but_submit'])){

    $comments = mysqli_real_escape_string($conn,$_POST['txt_comments']);

    if($_REQUEST['action'] == 'create'){
        $query = "INSERT INTO `attendees` (`user_id`,`event_id`,`comments`) VALUES (".$_SESSION['user_id'].",'".$event_id."','".$comments."')";
        if(mysqli_query($conn, $query)) {
           print '<div class="alert alert-success" role="alert">RSVP confirmed. <a href=event-details.php?event_id='.$event_id.'>Back</a></div>';
           header('Location: event-details.php?event_id='.$event_id);
        }
        else {
            $message = "<div class='alert alert-danger' role='alert'>ERROR during post creation. ". mysqli_error($conn)."</div>";
            include "templates\\post-form.html";
        }
    
    }
}

include "templates\\rsvp-form.html";
include "templates\\footer.html";