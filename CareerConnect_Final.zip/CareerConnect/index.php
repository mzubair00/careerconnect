<?php
include "config.php";
include "templates\\header.html";

if(!isset($_SESSION['username']))
{
    include "templates\\navigation-default.html";
} else {
    include "templates\\navigation-loggedin.html";
}

print "<main>";
print "<h3>Welcome to CareerConnect!</h3>";
if(!isset($_SESSION['username']))
{
    print "<p>Log-in or create an account.</p>";
}
else{
    print "<p>CareerConnect allows users to sign up for events and chat with each other on the forums. </br>To start, click on any of the options above.</p>";
    print "</br></br> In order to host your own events, contact an admin in the forums.";
}

include "templates\\footer.html";