<?php
include "config.php";
checkLoggedIn();
$reply_id = $_REQUEST['reply_id'];

if(!array_key_exists("action", $_REQUEST) || !in_array($_REQUEST['action'], array('edit', 'update','insert', 'create', 'delete'))) {
    print "<h4>No valid 'action' specified.</h4>";
}

if($_REQUEST['action'] == 'delete')
{
    $query = "delete from replies WHERE reply_id = " . $_REQUEST['reply_id'];
        if(mysqli_query($conn, $query)) {
            header('Location: forum.php');
        }
        else {
            di("<div class='alert alert-danger' role='alert'>ERROR during reply update. ". mysqli_error($conn)."</div>");
        }
}

include "templates\\header.html";
include "templates\\navigation-loggedin.html";

if($_REQUEST['action'] == 'create')
{
    $post_id = $_REQUEST['post_id'];
    $heading = "<h3>Create New Reply</h3><br />\r\n";
    $button = "Create Reply";
    $nextaction = "insert";
}

if($_REQUEST['action'] == 'edit')
{
    $reply = getReplyById($conn, $_REQUEST['reply_id']);

    $heading = "<h3>Update Reply - ".$reply['reply_id']."</h3><br />\r\n";
    $button = "Update Reply";
    $nextaction = "update";
    $reply_id = $reply['reply_id'];
    $post_id = $reply['post_id'];
    $title = $reply['title'];
    $body = $reply['body'];
}



if(isset($_POST['but_submit'])){

    $action = mysqli_real_escape_string($conn,$_POST['action']);
    $title = mysqli_real_escape_string($conn,$_POST['txt_title']);
    $body = mysqli_real_escape_string($conn,$_POST['txt_body']);
    $post_id = mysqli_real_escape_string($conn,$_POST['post_id']);
    
    if(isset($_POST['reply_id'])) { $post_id = mysqli_real_escape_string($conn,$_POST['reply_id']); }



    if($_REQUEST['action'] == 'insert'){
        $query = "INSERT INTO `replies` (`post_id`,`user_id`,`title`,`body`,`create_time`,`edit_time`) VALUES (".$post_id.",".$_SESSION['user_id'].",'".$title."','".$body."',NOW(),NOW())";
        if(mysqli_query($conn, $query)) {
           print '<div class="alert alert-success" role="alert">Reply successfully created. <a href=post.php?post_id='.$post_id.'>Back</a></div>';
        }
        else {
            $message = "<div class='alert alert-danger' role='alert'>ERROR during post creation. ". mysqli_error($conn)."</div>";
            include "templates\\reply-form.html";
        }
    }

    elseif($_REQUEST['action'] == 'update'){
        $query = "update replies set title = '".$title."', body = '".$body."', edit_time = NOW() WHERE reply_id = " . $reply_id;
        if(mysqli_query($conn, $query)) {
           print '<div class="alert alert-success" role="alert">Reply Successfully Updated. <a href=forum.php>Back</a></div>';
        }
        else {
            $message = "<div class='alert alert-danger' role='alert'>ERROR during reply update. ". mysqli_error($conn)."</div>";
            include "templates\\reply-form.html";
        }
    }

} else {
    
    include "templates\\reply-form.html";

}


include "templates\\footer.html";