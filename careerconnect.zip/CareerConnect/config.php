<?php

session_start();


$host = "localhost"; /* Host name */
$user = "root"; /* User */
$password = "P@ssw0rd#123"; /* Password */
$dbname = "careerconnect"; /* Database name */

$conn = mysqli_connect($host, $user, $password,$dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

function getUserById($conn, $user_id){
  $user_query = "select * from users where user_id = " . $user_id;
  $result = $conn->query($user_query);
  if($result->num_rows > 0)
  {
    return $result->fetch_assoc();
  }

}

function getRepliesforPost($conn, $post_id){
  $replies = array();
  $query = "select * from replies where post_id = " . $post_id;
  $result = $conn->query($query);
  while($row = $result->fetch_assoc()){
    $a = array_push($replies, $row);
  }
  return $replies;
}

function getPostCountForTopic($conn,$topic_id) {

  $query = "select count(*) as post_count from posts where topic_id = " . $topic_id;
  $result = $conn->query($query);
  $row = $result->fetch_assoc();
  return $row['post_count'];
}

// get all topics and their information.
function getTopics($conn, $sort) {

  $topics = array();

  if($sort == "") { $sort = "desc"; }
  $query = "select topic_id,subj,DATE_FORMAT(create_time, '%m/%d/%Y %r') As create_time from topics order by create_time ". $sort;
  $result = $conn->query($query);
  
  while($row = $result->fetch_assoc()){
      $t = [
            "subj" => $row['subj'], 
            "create_time"=> $row['create_time'], 
            "topic_id" => $row['topic_id'], 
            "post_count" => getPostCountForTopic($conn,$row['topic_id']) 
      ];
      array_push($topics, $t);
  }
  return $topics;
}

function getReplyCountforPost($conn,$post_id) {

  $query = "select count(*) as reply_count from replies where post_id = " . $post_id;
  $result = $conn->query($query);
  $row = $result->fetch_assoc();
  return $row['reply_count'];
}

function getPosts($conn, $topic_id) {

  $posts = array();

  $query = "select topic_id,post_id,user_id,title,body,DATE_FORMAT(create_time, '%m/%d/%Y %r') As create_time from posts WHERE topic_id = ".$topic_id." order by create_time desc";

  $result = $conn->query($query);
  
  while($row = $result->fetch_assoc()){
      $t = [
            "title" => $row['title'], 
            "body" => $row['body'], 
            "create_time"=> $row['create_time'], 
            "topic_id" => $row['topic_id'], 
            "user_id" => $row['user_id'],
            "post_id" => $row['post_id'],
            "reply_count" => getReplyCountforPost($conn,$row['post_id']) 
      ];
      array_push($posts, $t);
  }
  return $posts;
}

function getPostById($conn, $post_id) {

  $query = "SELECT `post_id`,`topic_id`,`user_id`,`title`,`body`,DATE_FORMAT(`create_time`, '%m/%d/%Y %r') As create_time, DATE_FORMAT(`edit_time`, '%m/%d/%Y %r') As edit_time FROM `careerconnect`.`posts` where post_id = " . $post_id;
  $result = $conn->query($query);
  $row = $result->fetch_assoc();

  $post = array(
    "post_id" => $row['post_id'], 
    "topic_id" => $row['topic_id'], 
    "user_id" => $row['user_id'], 
    "title" => $row['title'],
    "body" => $row['body'],
    "create_time" => $row['create_time'],
    "edit_time" => $row['edit_time'],
    "user" => getUserById($conn, $row['user_id']),
    "topic" => getTopicById($conn, $row['user_id'])
  );

  return $post;
}

function getReplyById($conn, $reply_id) {

  $query = "SELECT `reply_id`,`post_id`,`user_id`,`title`,`body`,DATE_FORMAT(`create_time`, '%m/%d/%Y %r') As create_time, DATE_FORMAT(`edit_time`, '%m/%d/%Y %r') As edit_time FROM `careerconnect`.`replies` where reply_id = " . $reply_id;
  $result = $conn->query($query);
  $row = $result->fetch_assoc();

  $reply = array(
    "reply_id" => $row['reply_id'],
    "post_id" => $row['post_id'], 
    "user_id" => $row['user_id'], 
    "title" => $row['title'],
    "body" => $row['body'],
    "create_time" => $row['create_time'],
    "edit_time" => $row['edit_time'],
    "user" => getUserById($conn, $row['user_id']),
    "post" => getPostById($conn,$row['user_id'])
  );

  return $reply;
}



function getReplies($conn, $post_id) {

  $replies = array();

  $query = "SELECT `reply_id`,`post_id`,`user_id`,`title`,`body`, DATE_FORMAT(`create_time`, '%m/%d/%Y %r') As create_time, DATE_FORMAT(`edit_time`, '%m/%d/%Y %r') As edit_time FROM `replies` WHERE post_id = ". $post_id." order by create_time asc";
  
  $result = $conn->query($query);
  
  while($row = $result->fetch_assoc()){
      $r = [
        "reply_id" => $row['reply_id'],
        "post_id" => $row['post_id'],
        "user_id" => $row['user_id'],
        "title" => $row['title'],
        "body" => $row['body'],
        "create_time" => $row['create_time'],
        "edit_time" => $row['edit_time'],
        "user" => getUserById($conn, $row['user_id']) 
      ];
      array_push($replies, $r);
  }
  return $replies;

}


function getTopicById($conn, $topic_id) {
  $query = "select * from topics where topic_id = " . $topic_id;
  $result = $conn->query($query);
  $row = $result->fetch_assoc();
  return $row;
}

function getEventById($conn, $event_id) {
  $query = "select * from events where event_id = " . $event_id;
  $result = $conn->query($query);
  $row = $result->fetch_assoc();
  return $row;
}

function checkLoggedIn(){
  if(!array_key_exists("LoggedIn", $_SESSION) || $_SESSION['LoggedIn'] != 1) {
    
    include "templates\\header.html";
    include "templates\\navigation-default.html";
    print "<h4>You must be logged in to access this area!";
    include "templates\\footer.html";
    die();
  }
}
