<?php
include "config.php";

checkLoggedIn();

include "templates\\header.html";
include "templates\\navigation-loggedin.html";


print "<main>";
print "<h3>Events</h3>";

if($_SESSION['permission'] < 3) {
    print '<div class="row"><div class="col-12 text-center mb-3">';
    print '<a href="event.php?action=create" class="btn btn-warning pull-right">New Event</a>';
    print '</div></div>';
}

$sql_query = "select * from events order by create_time desc";
        $result = $conn->query($sql_query);
if($result->num_rows > 0)
{
    while($row = $result->fetch_assoc()){
        print $row['title'] . " " . $row['time_begin'] ." ".$row['time_end']."<a href='details.php?event_id=".$row['event_id']."'>Event Details</a><br/>";
    }
}
else {
    print "No events.";
}

include "templates\\footer.html";