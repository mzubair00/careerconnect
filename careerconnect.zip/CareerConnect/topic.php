<?php
include "config.php";
checkLoggedIn();


include "templates\\header.html";
include "templates\\navigation-loggedin.html";

if(!array_key_exists("action", $_REQUEST) || !in_array($_REQUEST['action'], array('edit', 'update','insert', 'create'))) {
    print "<h4>No valid 'action' specified.</h4>";
}


if($_REQUEST['action'] == 'create')
{
    $heading = "<h3>Create New Topic</h3><br />\r\n";
    $button = "Create Topic";
    $nextaction = "insert";
}

if($_REQUEST['action'] == 'edit')
{
    $topic = getTopicById($conn, $_REQUEST['topic_id']);

    $heading = "<h3>Update Topic - ".$topic['topic_id']."</h3><br />\r\n";
    $button = "Update Topic";
    $nextaction = "update";
    $topic_id = $topic['topic_id'];
    $subj = $topic['subj'];
}



if(isset($_POST['but_submit'])){

    $action = mysqli_real_escape_string($conn,$_POST['action']);
    $subj = mysqli_real_escape_string($conn,$_POST['txt_subj']);

    if($_REQUEST['action'] == 'insert'){
        $query = "insert into topics (subj) values ('".$subj."')";
        if(mysqli_query($conn, $query)) {
           print '<div class="alert alert-success" role="alert">Topic Successfully created.</div>';
        }
        else {
            $message = "<div class='alert alert-danger' role='alert'>ERROR during topic creation. ". mysqli_error($conn)."</div>";
            include "templates\\topic-form.html";
        }
    }
    elseif($_REQUEST['action'] == 'update'){
        $query = "update topics set subj = '".$subj."', create_time = NOW() WHERE topic_id = " . $_REQUEST['topic_id'];
        if(mysqli_query($conn, $query)) {
           print '<div class="alert alert-success" role="alert">Topic Successfully Updated.</div>';
        }
        else {
            $message = "<div class='alert alert-danger' role='alert'>ERROR during topic update. ". mysqli_error($conn)."</div>";
            include "templates\\topic-form.html";
        }
    }

} else {
    
    include "templates\\topic-form.html";

}


include "templates\\footer.html";