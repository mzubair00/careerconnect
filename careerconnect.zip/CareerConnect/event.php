<?php
include "config.php";
checkLoggedIn();


include "templates\\header.html";
include "templates\\navigation-loggedin.html";

if(!array_key_exists("action", $_REQUEST) || !in_array($_REQUEST['action'], array('edit', 'update','insert','create'))) {
    print "<h4>No valid 'action' specified.</h4>";
}


if($_REQUEST['action'] == 'create')
{
    $heading = "<h3>Create New Event</h3><br />\r\n";
    $button = "Create Event";
    $nextaction = "insert";
}

if($_REQUEST['action'] == 'edit')
{
    $event = getEventById($conn, $_REQUEST['event_id']);

    $heading = "<h3>Edit Event - ".$event['event_id']."</h3><br />\r\n";
    $button = "Edit Event";
    $nextaction = "update";
    $event_id = $event['event_id'];
    $title = $event['title'];
    $description = $event['description'];
    $time_begin = $event['time_begin'];
    $time_end = $event['time_end'];
    $location = $event['location'];
}



if(isset($_POST['but_submit'])){

    $action = mysqli_real_escape_string($conn,$_POST['action']);
    $title = mysqli_real_escape_string($conn,$_POST['txt_title']);
    $description = mysqli_real_escape_string($conn,$_POST['txt_description']);
    $time_begin = mysqli_real_escape_string($conn,$_POST['txt_starttime']);
    $time_end = mysqli_real_escape_string($conn,$_POST['txt_endtime']);
    $location = mysqli_real_escape_string($conn,$_POST['txt_location']);
    $user_id = mysqli_real_escape_string($conn,$_SESSION['user_id']);


    if($_REQUEST['action'] == 'insert'){
        $query = "insert into events (user_id,title,description,time_begin,time_end,location) values (".$user_id.",'".$title."','".$description."','".$time_begin."','".$time_end."','".$location."')";
        if(mysqli_query($conn, $query)) {
           print '<div class="alert alert-success" role="alert">Event Successfully created.</div>';
        }
        else {
            $message = "<div class='alert alert-danger' role='alert'>ERROR during error creation. ". mysqli_error($conn)."</div>";
            include "templates\\event-form.html";
        }
    }
   // elseif($_REQUEST['action'] == 'update'){
   //      $query = "update events set subj = '".$subj."', create_time = NOW() WHERE topic_id = " . $_REQUEST['topic_id'];
   //     if(mysqli_query($conn, $query)) {
   //        print '<div class="alert alert-success" role="alert">Topic Successfully Updated.</div>';
   //     }
   //     else {
   //         $message = "<div class='alert alert-danger' role='alert'>ERROR during topic update. ". mysqli_error($conn)."</div>";
   //         include "templates\\topic-form.html";
   //     }
   // }

} else {
    
    include "templates\\event-form.html";

}


include "templates\\footer.html";