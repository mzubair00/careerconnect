<?php
include "config.php";
include "templates\\header.html";

if(!isset($_SESSION['username']))
{
    include "templates\\navigation-default.html";
} else {
    include "templates\\navigation-loggedin.html";
}

print "<main>";
print "<h3>Welcome to CareerConnect!</h3>";
if(!isset($_SESSION['username']))
{
    print "<p>Log-in or create an account.</p>";
}
else{
    print "<p>Forums and Events.</p>";
}

include "templates\\footer.html";