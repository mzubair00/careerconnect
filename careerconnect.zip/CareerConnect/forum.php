<?php
include "config.php";

checkLoggedIn();


include "templates\\header.html";

if(!isset($_SESSION['username']))
{
    include "templates\\navigation-default.html";
} else {
    include "templates\\navigation-loggedin.html";
}

print "<main>";
print "<h3>Current Topics</h3><br />";
print "<div class='container'>";
if($_SESSION['permission'] == 0) {
    print '<div class="row"><div class="col-12 text-center mb-3">';
    print '<a href="topic.php?action=create" class="btn btn-warning pull-right">New Topic</a>';
    print '</div></div>';
}

$topics = getTopics($conn, "desc");

if(sizeof($topics)< 1)
{
    print "<p class='fs-4'>No Topics Found.</p>";
}
else{
    foreach($topics as &$topic)
    {
        include "templates\\topic-list.html";
    }
}


print '</div>';
include "templates\\footer.html";